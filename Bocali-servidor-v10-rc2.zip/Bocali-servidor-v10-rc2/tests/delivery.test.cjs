'use strict';
const assert=require('node:assert/strict'),D=require('../delivery.js'),C=require('../domain.js');
let count=0;function test(n,f){f();console.log('PASS '+n);count++;}
function setup(){const s=D.migrate(C.seed()),p=s.products[0];s.cart={storeId:p.storeId,items:[{id:'x',productId:p.id,name:p.name,unitPrice:p.price,quantity:2,extras:[],note:''}]};return s;}
function point(i){return D.sample(i).point;}
test('three known areas have independent fees',()=>{const s=setup();assert.deepEqual([0,1,2].map(i=>D.quote(s.stores[0],point(i)).fee),[500,800,1200]);});
test('outside never falls back to flat fee or free delivery',()=>{const s=setup(),q=D.quote(s.stores[0],point(3));assert.equal(q.ok,false);assert.equal(q.fee,undefined);});
test('invalid points rejected',()=>{const s=setup();for(const p of [null,{lng:NaN,lat:0},{lng:0,lat:100},{lng:'0',lat:0}])assert.equal(D.quote(s.stores[0],p).ok,false);});
test('shared edges and vertices are included deterministically',()=>{const r=[[0,0],[2,0],[2,2],[0,2]];for(const p of [{lng:0,lat:0},{lng:1,lat:0},{lng:1,lat:1}])assert.equal(D.inRing(p,r),true);assert.equal(D.inRing({lng:3,lat:1},r),false);});
test('overlap uses explicit priority rather than sum or price',()=>{const s=setup(),q=D.quote(s.stores[0],point(0));assert.equal(q.fee,500);assert.equal(q.priority,30);assert.equal(q.overlap,true);});
test('overlap with equal priority is blocked',()=>{const s=setup();s.stores[0].deliveryConfig.zones[1].priority=30;assert.equal(D.quote(s.stores[0],point(0)).code,'conflict');});
test('exclusion wins over normal priority',()=>{const s=setup();s.stores[0].deliveryConfig.zones[0].kind='blocked';s.stores[0].deliveryConfig.zones[0].priority=0;assert.equal(D.quote(s.stores[0],point(0)).code,'blocked');});
test('paused zones are ignored',()=>{const s=setup();s.stores[0].deliveryConfig.zones[0].active=false;assert.equal(D.quote(s.stores[0],point(0)).fee,800);});
test('zero fee is legitimate inside a configured zone',()=>{const s=setup();s.stores[0].deliveryConfig.zones[0].fee=0;const d=D.confirmSelection(s.stores[0],D.sample(0));const o=C.createOrder(s,{fulfillment:'delivery',payment:'cash',delivery:d});assert.equal(o.fee,0);assert.equal(o.total,2980);});
test('shop isolation: same point can have different fees',()=>{const s=setup();assert.equal(D.quote(s.stores[1],point(0)).fee,600);s.stores[0].deliveryConfig.zones[0].fee=200;assert.equal(D.quote(s.stores[1],point(0)).fee,600);});
test('foreign zones are not used',()=>{const s=setup();s.stores[0].deliveryConfig.zones.forEach(z=>z.storeId='other');assert.equal(D.quote(s.stores[0],point(0)).ok,false);});
test('address must be complete',()=>{const a=D.sample().address;assert.equal(D.validAddress(a),true);a.number='';assert.equal(D.validAddress(a),false);});
test('delivery checkout requires confirmed selection',()=>{const s=setup();assert.throws(()=>C.createOrder(s,{fulfillment:'delivery',payment:'cash'}));assert.equal(s.orders.length,0);assert.equal(s.cart.items.length,1);});
test('uncertain geocoding cannot be confirmed',()=>{const s=setup(),v=D.sample();v.precise=false;assert.throws(()=>D.confirmSelection(s.stores[0],v));});
test('typed address edit invalidates previous confirmation',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample());d.address.number='102';assert.throws(()=>D.validateDelivery(s.stores[0],d));});
test('fee tampering rejected',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample());d.quote.fee=1;assert.throws(()=>D.validateDelivery(s.stores[0],d));});
test('cross-store quote rejected',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample());assert.throws(()=>D.validateDelivery(s.stores[1],d));});
test('configuration changes require new customer confirmation',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample()),z=D.clone(s.stores[0].deliveryConfig.zones[0]);z.fee=650;D.saveZone(s.stores[0],z);assert.throws(()=>D.validateDelivery(s.stores[0],d));});
test('expired address confirmation rejected',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample());assert.throws(()=>D.validateDelivery(s.stores[0],d,Date.parse(d.confirmedAt)+601000));});
test('new order stores immutable original fee and address snapshot',()=>{const s=setup(),d=D.confirmSelection(s.stores[0],D.sample(1)),o=C.createOrder(s,{fulfillment:'delivery',payment:'pix',delivery:d});assert.equal(o.fee,800);assert.equal(o.total,3780);d.address.street='changed';s.stores[0].deliveryConfig.zones[1].fee=999;assert.equal(o.fee,800);assert.equal(o.delivery.address.street,'Rua Exemplo B');});
test('pickup costs zero and needs no address or delivery zones',()=>{const s=setup();s.stores[0].deliveryConfig.zones=[];const o=C.createOrder(s,{fulfillment:'pickup',payment:'cash'});assert.equal(o.fee,0);assert.equal(o.delivery,null);});
test('self intersecting polygon rejected',()=>{const s=setup(),z=D.clone(s.stores[0].deliveryConfig.zones[0]);z.ring=[[0,0],[2,2],[0,2],[2,0]];assert.throws(()=>D.validateZone(z,s.stores[0].id));});
test('collinear and repeated vertices rejected',()=>{const s=setup(),z=D.clone(s.stores[0].deliveryConfig.zones[0]);for(const r of [[[0,0],[1,1],[2,2]],[[0,0],[0,0],[1,1]]]){z.ring=r;assert.throws(()=>D.validateZone(z,s.stores[0].id));}});
test('invalid and negative fees rejected',()=>{const s=setup(),z=D.clone(s.stores[0].deliveryConfig.zones[0]);for(const f of [-1,null,1.5,100001]){z.fee=f;assert.throws(()=>D.validateZone(z,s.stores[0].id));}});
test('migrating old saved state never mutates historical orders',()=>{const s=C.seed();s.orders=[{id:'old',fee:500}];D.migrate(s);D.migrate(s);assert.equal(s.stores[0].deliveryConfig.revision,1);assert.equal(s.orders[0].fee,500);});
console.log(count+' delivery tests passed.');
