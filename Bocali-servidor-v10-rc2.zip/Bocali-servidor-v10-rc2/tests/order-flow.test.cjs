'use strict';
const assert=require('node:assert/strict'),C=require('../domain.js'),O=require('../order-flow.js');
let passed=0;function test(name,fn){fn();console.log('PASS '+name);passed++;}
function make(mode='delivery'){const s=C.seed(),p=s.products[0];s.cart={storeId:p.storeId,items:[{id:'x',productId:p.id,name:p.name,unitPrice:p.price,extras:[{...p.extras[0]}],quantity:2,note:'Sem azeitona'}]};return C.createOrder(s,{fulfillment:mode,payment:'cash',note:'Separar embalagens'});}
const now='2026-09-20T22:00:00.000Z';
test('delivery ETA counts from acceptance including transport',()=>{const o=make();O.accept(o,45,60,now);assert.equal(o.status,'accepted');assert.equal(o.eta.from,'2026-09-20T22:45:00.000Z');assert.equal(o.eta.to,'2026-09-20T23:00:00.000Z');assert.equal(o.events[1].at,now);});
test('pickup has its own preparation ETA',()=>{const o=make('pickup');O.accept(o,'15','25',now);assert.equal(o.eta.fulfillment,'pickup');assert.equal(o.eta.to,'2026-09-20T22:25:00.000Z');});
test('ETA rolls over day boundaries',()=>{const o=make();O.accept(o,90,120,'2026-09-20T23:30:00.000Z');assert.equal(o.eta.to,'2026-09-21T01:30:00.000Z');});
test('invalid ETA leaves order unchanged',()=>{for(const [min,max] of [[0,10],[30,20],[1,241],[1.5,30],['x',30],['',30],[1,NaN]]){const o=make();assert.throws(()=>O.accept(o,min,max,now));assert.equal(o.status,'new');assert.equal(o.eta,undefined);}});
test('invalid acceptance date rejected without mutation',()=>{const o=make();assert.throws(()=>O.accept(o,10,20,'invalid'));assert.equal(o.eta,undefined);});
test('double acceptance cannot move the confirmed ETA',()=>{const o=make();O.accept(o,10,20,now);const before=JSON.stringify(o);assert.throws(()=>O.accept(o,30,40));assert.equal(JSON.stringify(o),before);});
test('acceptance requires ETA even via legacy transition',()=>assert.throws(()=>C.transition(make(),'accepted')));
test('delivery must be dispatched before completion',()=>{const o=make();O.accept(o,30,40,now);C.transition(o,'preparing');C.transition(o,'ready');assert.throws(()=>C.transition(o,'completed'));C.transition(o,'dispatched');C.transition(o,'completed');assert.equal(o.status,'completed');});
test('pickup cannot be dispatched',()=>{const o=make('pickup');O.accept(o,10,20,now);C.transition(o,'preparing');C.transition(o,'ready');assert.throws(()=>C.transition(o,'dispatched'));C.transition(o,'completed');});
test('new and refused orders cannot produce cooking tickets',()=>{const o=make();assert.throws(()=>O.requestPrint(o));C.transition(o,'cancelled');assert.throws(()=>O.requestPrint(o));assert.throws(()=>O.requestPrint(o,{kind:'cancellation'}));});
test('request is not print success',()=>{const o=make();O.accept(o,30,40,now);const j=O.requestPrint(o);assert.equal(j.status,'requested');assert.equal(O.printState(o),'pending');assert.equal(j.sequence,1);});
test('unconfirmed request blocks another accidental print',()=>{const o=make();O.accept(o,30,40,now);O.requestPrint(o);assert.throws(()=>O.requestPrint(o));assert.equal(o.printJobs.length,1);});
test('operator must explicitly confirm receipt of paper',()=>{const o=make();O.accept(o,30,40,now);const j=O.requestPrint(o);O.resolvePrint(o,j.id,true);assert.equal(O.printState(o),'confirmed');assert.equal(j.status,'confirmed_by_operator');assert.throws(()=>O.resolvePrint(o,j.id,false));});
test('cancelled print dialog can be marked failed then reprinted',()=>{const o=make();O.accept(o,30,40,now);const j=O.requestPrint(o,{paper:58});O.resolvePrint(o,j.id,false);assert.equal(O.printState(o),'failed');const second=O.requestPrint(o);assert.equal(second.sequence,2);assert.equal(O.printState(o),'pending');});
test('kitchen and counter are independent print records',()=>{const o=make();O.accept(o,30,40,now);O.requestPrint(o,{kind:'counter'});assert.equal(O.printState(o),'not_requested');assert.equal(O.printState(o,'counter'),'pending');});
test('cancellation slip after acceptance never permits kitchen reprint',()=>{const o=make();O.accept(o,30,40,now);C.transition(o,'cancelled');assert.throws(()=>O.requestPrint(o));const j=O.requestPrint(o,{kind:'cancellation'});assert.equal(j.kind,'cancellation');});
test('only supported paper widths accepted',()=>{const o=make();O.accept(o,30,40,now);assert.throws(()=>O.requestPrint(o,{paper:90}));assert.equal(o.printJobs,undefined);});
test('unknown receipt kind and invalid confirmation are rejected',()=>{const o=make();O.accept(o,30,40,now);assert.throws(()=>O.requestPrint(o,{kind:'other'}));const j=O.requestPrint(o);assert.throws(()=>O.resolvePrint(o,j.id,'true'));assert.equal(j.status,'requested');});
test('invalid print date leaves order unchanged',()=>{const o=make();O.accept(o,30,40,now);assert.throws(()=>O.requestPrint(o,{now:'invalid'}));assert.equal(o.printJobs,undefined);});
test('invalid resolution date does not alter status',()=>{const o=make();O.accept(o,30,40,now);const j=O.requestPrint(o);assert.throws(()=>O.resolvePrint(o,j.id,true,'invalid'));assert.equal(j.status,'requested');});
console.log(`${passed} acceptance/printing tests passed.`);
