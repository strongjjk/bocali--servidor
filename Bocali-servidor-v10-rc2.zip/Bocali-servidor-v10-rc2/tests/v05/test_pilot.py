"""WSGI and storage tests. All accounts and orders are disposable fixtures."""
from __future__ import annotations
import io, json, sys, tempfile, time, unittest
from dataclasses import replace
from http.cookies import SimpleCookie
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlsplit
from wsgiref.util import setup_testing_defaults
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from pilot_app import PilotApp, Settings, RateLimiter
from backend import Database, Problem
from backup import create_backup, verify_backup, restore_backup

PASSWORD='SomenteTeste2026!'
CODE='CodigoSomenteParaTeste-Aleatorio-123456'
SECRET='SegredoFicticioSomenteTestes-abcdefghijklmnopqrstuvwxyz'
SETUP='ChaveFicticiaSomenteSetup-abcdefghijklmnopqrstuvwxyz'

class Client:
    def __init__(self,app):self.app=app;self.cookies=SimpleCookie();self.csrf=''
    def call(self,path,body=None,method=None,headers=None,raw=None):
        e={};setup_testing_defaults(e)
        e.update(REQUEST_METHOD=method or ('POST' if body is not None or raw is not None else 'GET'),
            PATH_INFO=path,HTTP_HOST=urlsplit(self.app.settings.origin).netloc,
            REMOTE_ADDR='127.0.0.1',HTTP_ORIGIN=self.app.settings.origin,
            HTTP_X_PEDE_REQUEST='1',HTTP_X_CSRF_TOKEN=self.csrf,
            HTTP_COOKIE='; '.join(m.OutputString() for m in self.cookies.values()))
        if raw is not None:e['wsgi.input']=io.BytesIO(raw);e['CONTENT_LENGTH']=str(len(raw));e['CONTENT_TYPE']='application/json'
        elif body is not None:
            data=json.dumps(body).encode();e['wsgi.input']=io.BytesIO(data);e['CONTENT_LENGTH']=str(len(data));e['CONTENT_TYPE']='application/json'
        if headers:e.update(headers)
        result={}
        def start(status,h):result.update(status=int(status.split()[0]),headers=h)
        value=b''.join(self.app(e,start));result['raw']=value
        for k,v in result['headers']:
            if k.lower()=='set-cookie':self.cookies.load(v)
        try:result['json']=json.loads(value)
        except (ValueError,UnicodeDecodeError):result['json']=None
        return result
    def unlock(self):return self.call('/api/pilot-unlock',{'code':CODE})
    def login(self,email='owner@example.com'):
        self.unlock();r=self.call('/api/login',{'email':email,'password':PASSWORD})
        boot=self.call('/api/bootstrap')['json'];self.csrf=boot.get('csrf','');return r
    def setup(self):
        self.unlock();r=self.call('/api/setup-owner',{'setupToken':SETUP,'name':'Responsavel teste','email':'owner@example.com','password':PASSWORD})
        self.csrf=self.call('/api/bootstrap')['json'].get('csrf','');return r
    def customer(self):
        self.unlock();r=self.call('/api/register',{'name':'Cliente teste','email':'client@example.com','password':PASSWORD})
        self.csrf=self.call('/api/bootstrap')['json'].get('csrf','');return r

class PilotTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.cfg=Settings('https://pede.example',self.root,'protected',CODE,SECRET,SETUP)
        self.app=PilotApp(self.cfg);self.c=Client(self.app)
    def tearDown(self):self.tmp.cleanup()
    def order(self):
        self.c.setup();c=Client(self.app);c.customer()
        payload={'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':['cheese']}],
            'fulfillment':'delivery','payment':'cash','sampleIndex':1,'address':self.app.db.seed['samples'][1]['address']}
        q=c.call('/api/quote',payload);self.assertEqual(q['status'],200,q)
        order=c.call('/api/orders',{'quoteId':q['json']['quoteId'],'idempotencyKey':'wsgi-test-order-123456'})
        self.assertEqual(order['status'],201,order);return c,order['json']['order']

    def test_gate_blocks_bootstrap(self):
        r=self.c.call('/api/bootstrap');self.assertEqual(r['status'],403);self.assertTrue(r['json']['gateRequired'])
    def test_gate_page_contains_no_catalog(self):
        r=self.c.call('/');self.assertEqual(r['status'],200);self.assertIn(b'pilot-form',r['raw']);self.assertNotIn(b'R$ 14,90',r['raw'])
    def test_unlock_wrong_code(self):self.assertEqual(self.c.call('/api/pilot-unlock',{'code':'wrong'})['status'],401)
    def test_unlock_sets_secure_httponly_cookie(self):
        r=self.c.unlock();self.assertEqual(r['status'],200);h=str(r['headers']);self.assertIn('Secure',h);self.assertIn('HttpOnly',h);self.assertIn('SameSite=Lax',h);self.assertNotIn(CODE,h)
    def test_unlock_exposes_no_personal_data_to_guest(self):
        self.c.unlock();r=self.c.call('/api/bootstrap')['json'];self.assertIsNone(r['user']);self.assertEqual(r['merchantOrders'],[])
    def test_gate_cookie_expires(self):
        self.c.unlock()
        with patch('pilot_app.time.time',return_value=time.time()+9*3600):self.assertEqual(self.c.call('/api/bootstrap')['status'],403)
    def test_gate_cookie_tampering(self):
        self.c.unlock();self.c.cookies['pede_pilot']=self.c.cookies['pede_pilot'].value+'x';self.assertEqual(self.c.call('/api/bootstrap')['status'],403)
    def test_gate_code_rotation_invalidates_cookie(self):
        self.c.unlock();self.c.app=PilotApp(replace(self.cfg,pilot_code=CODE+'new'));self.assertEqual(self.c.call('/api/bootstrap')['status'],403)
    def test_gate_rate_limit(self):
        for i in range(15):self.assertEqual(self.c.call('/api/pilot-unlock',{'code':'wrong'})['status'],401)
        self.assertEqual(self.c.unlock()['status'],429)
    def test_cross_origin_denied(self):
        self.assertEqual(self.c.call('/api/pilot-unlock',{'code':CODE},headers={'HTTP_ORIGIN':'https://evil.example'})['status'],403)
    def test_missing_origin_denied(self):
        self.assertEqual(self.c.call('/api/pilot-unlock',{'code':CODE},headers={'HTTP_ORIGIN':''})['status'],403)
    def test_missing_custom_header_denied(self):
        self.assertEqual(self.c.call('/api/pilot-unlock',{'code':CODE},headers={'HTTP_X_PEDE_REQUEST':''})['status'],403)
    def test_wrong_host_denied(self):self.assertEqual(self.c.call('/healthz',headers={'HTTP_HOST':'evil.example'})['status'],403)
    def test_healthcheck_host_only_accesses_health(self):
        h={'HTTP_HOST':'healthcheck.railway.app'}
        self.assertEqual(self.c.call('/healthz',headers=h)['status'],200)
        self.assertEqual(self.c.call('/api/bootstrap',headers=h)['status'],403)
    def test_healthcheck_reveals_no_details(self):self.assertEqual(self.c.call('/healthz')['json'],{'ok':True})
    def test_head_body_is_empty(self):self.assertEqual(self.c.call('/',method='HEAD')['raw'],b'')
    def test_headers_disable_caching_and_indexing(self):
        h=dict(self.c.call('/')['headers']);self.assertEqual(h['Cache-Control'],'no-store');self.assertIn('noindex',h['X-Robots-Tag']);self.assertIn("frame-ancestors 'none'",h['Content-Security-Policy'])
    def test_source_db_and_backups_not_served(self):
        self.c.unlock()
        for path in ['/pilot_app.py','/backup.py','/.env','/data/pede.sqlite3','/data/backups/a.sqlite3','/seed.json','/../backend.py']:
            with self.subTest(path=path):self.assertEqual(self.c.call(path)['status'],404)
    def test_setup_requires_separate_secret(self):
        self.c.unlock();r=self.c.call('/api/setup-owner',{'setupToken':CODE,'email':'owner@example.com','password':PASSWORD,'name':'Teste'});self.assertEqual(r['status'],403)
    def test_setup_creates_owner_session(self):
        self.assertEqual(self.c.setup()['status'],201);self.assertEqual(self.c.call('/api/bootstrap')['json']['managedStores'],['cantinho'])
    def test_setup_can_only_be_used_once_without_orphan_accounts(self):
        self.c.setup();r=self.c.call('/api/setup-owner',{'setupToken':SETUP,'email':'other@example.com','password':PASSWORD,'name':'Outro'});self.assertEqual(r['status'],409)
        with self.app.db.connect() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM users').fetchone()[0],1)
    def test_new_store_registration_cannot_take_cantinho(self):
        self.c.setup();c=Client(self.app);c.unlock()
        r=c.call('/api/register',{'name':'Outra','email':'other@example.com','password':PASSWORD,'mode':'merchant','storeName':'Outra loja','storeId':'cantinho'})
        self.assertEqual(r['status'],201);self.assertNotIn('cantinho',c.call('/api/bootstrap')['json']['managedStores'])
    def test_customer_cannot_read_operations(self):self.c.customer();self.assertEqual(self.c.call('/api/pilot-status')['status'],403)
    def test_guest_cannot_read_operations(self):self.c.unlock();self.assertEqual(self.c.call('/api/pilot-status')['status'],401)
    def test_operations_returns_truthful_flags_without_secrets(self):
        self.c.setup();r=self.c.call('/api/pilot-status');self.assertEqual(r['status'],200);d=r['json'];self.assertEqual(d['payments'],'simulation');self.assertFalse(d['automaticBackupConfigured']);self.assertFalse(d['geocodingValidated']);self.assertNotIn(SECRET,str(d));self.assertNotIn(str(self.root),str(d))
    def test_csrf_still_required(self):
        self.c.setup();self.c.csrf='wrong';self.assertEqual(self.c.call('/api/favorites',{'storeId':'cantinho','saved':True})['status'],403)
    def test_unsafe_json_rejected(self):
        self.c.unlock();self.assertEqual(self.c.call('/api/login',raw=b'{"x":NaN}')['status'],400)
    def test_non_object_json_rejected(self):self.c.unlock();self.assertEqual(self.c.call('/api/login',raw=b'[]')['status'],400)
    def test_upload_limit_checked_before_read(self):
        self.c.unlock();r=self.c.call('/api/login',raw=b'{}',headers={'CONTENT_LENGTH':'999999999'});self.assertEqual(r['status'],413)
    def test_unknown_method_denied(self):self.assertEqual(self.c.call('/',method='DELETE')['status'],405)
    def test_pdf_is_disabled_by_default(self):self.c.setup();self.assertEqual(self.c.call('/api/import-pdf',raw=b'%PDF-test')['status'],503)
    def test_order_total_and_acceptance_in_new_wsgi_adapter(self):
        c,o=self.order();self.assertEqual(o['total'],2590)
        r=self.c.call('/api/order-action',{'orderId':o['id'],'expectedRevision':1,'action':'accept','min':35,'max':55})
        self.assertEqual(r['status'],200);self.assertEqual(c.call('/api/bootstrap')['json']['customerOrders'][0]['eta']['minMinutes'],35)
    def test_order_persists_after_app_restart(self):
        c,o=self.order();c.app=PilotApp(self.cfg);self.assertEqual(c.call('/api/bootstrap')['json']['customerOrders'][0]['id'],o['id'])
    def test_pilot_lock_invalidates_login_and_gate(self):
        self.c.setup();self.assertEqual(self.c.call('/api/pilot-lock',{})['status'],200);self.assertEqual(self.c.call('/api/bootstrap')['status'],403)
        self.c.unlock();self.assertIsNone(self.c.call('/api/bootstrap')['json']['user'])
    def test_static_ui_assets_served(self):
        self.c.setup()
        for name in ['operations.js','operations.css','setup.js','pilot.css','loader.js']:
            with self.subTest(name=name):self.assertEqual(self.c.call('/'+name)['status'],200)
    def test_backup_restore_preserves_orders_and_invalidates_sessions(self):
        c,o=self.order();snapshot=self.root/'backups'/'test.sqlite3';result=create_backup(self.app.db.path,snapshot)
        self.assertEqual(result['orders'],1);self.assertEqual(verify_backup(snapshot)['orders'],1)
        target=self.root/'restored'/'pede.sqlite3';result=restore_backup(snapshot,target);self.assertTrue(result['sessionsInvalidated'])
        import sqlite3
        with sqlite3.connect(target) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM sessions').fetchone()[0],0)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM quotes').fetchone()[0],0)
            self.assertEqual(db.execute('SELECT id FROM orders').fetchone()[0],o['id'])
    def test_backup_refuses_overwrite(self):
        out=self.root/'copy.sqlite3';create_backup(self.app.db.path,out)
        with self.assertRaises(FileExistsError):create_backup(self.app.db.path,out)
    def test_restore_refuses_overwrite(self):
        out=self.root/'copy.sqlite3';create_backup(self.app.db.path,out)
        with self.assertRaises(FileExistsError):restore_backup(out,self.app.db.path)
    def test_corrupt_snapshot_hash_rejected(self):
        out=self.root/'copy.sqlite3';create_backup(self.app.db.path,out)
        with out.open('ab') as f:f.write(b'corrupted')
        with self.assertRaises(ValueError):restore_backup(out,self.root/'restored.sqlite3')
        self.assertFalse((self.root/'restored.sqlite3').exists())
    def test_missing_source_does_not_create_empty_backup(self):
        with self.assertRaises(FileNotFoundError):create_backup(self.root/'missing.sqlite3',self.root/'bad.sqlite3')
        self.assertFalse((self.root/'bad.sqlite3').exists())

class ConfigurationTests(unittest.TestCase):
    def test_protected_requires_https(self):
        with self.assertRaises(ValueError):Settings('http://pede.example',Path('/tmp/data'),'protected',CODE,SECRET).validate()
    def test_protected_requires_strong_gate(self):
        with self.assertRaises(ValueError):Settings('https://pede.example',Path('/tmp/data'),'protected','short',SECRET).validate()
    def test_origin_must_not_have_path(self):
        with self.assertRaises(ValueError):Settings('https://pede.example/path',Path('/tmp/data'),'protected',CODE,SECRET).validate()
    def test_origin_must_not_have_password(self):
        with self.assertRaises(ValueError):Settings('https://user:pass@pede.example',Path('/tmp/data'),'protected',CODE,SECRET).validate()
    def test_local_mode_restricted_to_loopback(self):
        with self.assertRaises(ValueError):Settings('http://0.0.0.0:8000',Path('/tmp/data')).validate()
    def test_environment_requires_volume_on_railway(self):
        with patch.dict('os.environ',{'PEDE_MODE':'protected','PEDE_PUBLIC_ORIGIN':'https://pede.example','PEDE_PILOT_CODE':CODE,'PEDE_SECRET_KEY':SECRET,'RAILWAY_ENVIRONMENT_ID':'test'},clear=True):
            with self.assertRaises(ValueError):Settings.from_env()

if __name__=='__main__':unittest.main(verbosity=2)
