from __future__ import annotations
import json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from backend import Database
from pilot_app import Settings
PASSWORD='SomenteTeste2026!'

class IntegratedTests(unittest.TestCase):
    def test_lan_accepts_private_ipv4(self):
        s=Settings('http://192.168.1.20:8000',Path(tempfile.mkdtemp()),'lan','x'*24,'y'*32,'z'*32)
        s.validate();self.assertFalse(s.secure)
    def test_lan_rejects_public_ipv4(self):
        with self.assertRaises(ValueError):
            Settings('http://8.8.8.8:8000',Path(tempfile.mkdtemp()),'lan','x'*24,'y'*32,'z'*32).validate()
    def test_print_result_retry_after_lost_response_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            db=Database(Path(td)/'db.sqlite3',ROOT/'seed.json')
            db.setup_owner('owner@example.com',PASSWORD,'Owner')
            token=db.register({'email':'client@example.com','password':PASSWORD,'name':'Cliente'})
            with db.connect() as c:
                uid=c.execute("SELECT id FROM users WHERE email='client@example.com'").fetchone()[0]
                owner=c.execute("SELECT id FROM users WHERE email='owner@example.com'").fetchone()[0]
            payload={'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':[]}],'fulfillment':'pickup','payment':'cash'}
            q=db.quote(uid,payload);o=db.create_order(uid,{'quoteId':q['quoteId'],'idempotencyKey':'integrated-order-00001'})['order']
            o=db.action(owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'accept','min':15,'max':25})['order']
            o=db.action(owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'print','kind':'kitchen','paper':80})['order']
            job=o['printJobs'][0];stale=o['revision']
            first=db.action(owner,{'orderId':o['id'],'expectedRevision':stale,'action':'print-result','jobId':job['id'],'success':True})['order']
            second=db.action(owner,{'orderId':o['id'],'expectedRevision':stale,'action':'print-result','jobId':job['id'],'success':True})['order']
            self.assertEqual(first['printJobs'][0]['status'],'confirmed_by_operator')
            self.assertEqual(second['printJobs'][0]['status'],'confirmed_by_operator')

if __name__=='__main__':unittest.main(verbosity=2)
