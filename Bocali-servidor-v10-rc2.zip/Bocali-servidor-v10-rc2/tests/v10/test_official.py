from __future__ import annotations
import hashlib,hmac,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from backend import Database,Problem
from mercadopago_service import MercadoPagoService
from pilot_app import PilotApp,Settings
PASSWORD='SenhaExclusiva2026!'

class FakeMP(MercadoPagoService):
    def __init__(self):
        super().__init__('token-servidor','TEST-public','webhook-secret')
        self.calls=[]
    def _request(self,method,path,payload=None,idempotency_key=None):
        self.calls.append((method,path,payload,idempotency_key))
        if path.endswith('/refunds'):
            return {'id':987,'payment_id':123,'status':'approved','amount':12.34}
        if path=='/checkout/preferences':
            return {'id':'PREF-1','init_point':'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=PREF-1','sandbox_init_point':'https://sandbox.mercadopago.com.br/checkout/v1/redirect?pref_id=PREF-1','external_reference':payload.get('external_reference','')}
        return {'id':123,'status':'pending','status_detail':'pending_waiting_payment','payment_method_id':payload.get('payment_method_id','pix') if payload else 'pix','external_reference':payload.get('external_reference','') if payload else '', 'point_of_interaction':{'transaction_data':{'qr_code':'PIX-CODE','qr_code_base64':'AAA'}}}

class OfficialCoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def db(self,seed=True):return Database(self.path/'db.sqlite3',ROOT/'seed.json',allow_samples=True,seed_catalog=seed)

    def test_production_database_starts_without_hardcoded_restaurant(self):
        db=self.db(False)
        self.assertEqual(db.bootstrap(None)['stores'],[])
        db.register({'email':'cliente@example.com','password':PASSWORD,'name':'Cliente','mode':'customer'})
        self.assertEqual(db.bootstrap(None)['stores'],[])

    def test_merchant_registration_creates_own_paused_store(self):
        db=self.db(False)
        token=db.register({'email':'loja@example.com','password':PASSWORD,'name':'Responsável','mode':'merchant','storeName':'Cantinho do Pastel'})
        session=db.session(token);boot=db.bootstrap(session)
        self.assertEqual(len(boot['managedStores']),1);self.assertEqual(len(boot['stores']),1)
        store=boot['stores'][0];self.assertEqual(store['name'],'Cantinho do Pastel');self.assertFalse(store['open']);self.assertEqual(store['tag'],'Loja no Bocali')

    def _paid_fixture(self):
        db=self.db(True);db.setup_owner('dono@example.com',PASSWORD,'Dono')
        db.register({'email':'cliente@example.com','password':PASSWORD,'name':'Cliente'})
        with db.connect() as c:
            client=c.execute("SELECT id FROM users WHERE email='cliente@example.com'").fetchone()[0]
            owner=c.execute("SELECT id FROM users WHERE email='dono@example.com'").fetchone()[0]
        payload={'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':[],'note':''}],'fulfillment':'pickup','payment':'pix','note':''}
        quote=db.quote(client,payload)
        order=db.create_order(client,{'quoteId':quote['quoteId'],'idempotencyKey':'official-order-000001'})['order']
        return db,client,owner,order

    def test_online_order_waits_for_provider_before_reaching_merchant(self):
        db,client,owner,order=self._paid_fixture()
        self.assertEqual(order['status'],'awaiting_payment');self.assertEqual(order['paymentStatus'],'pending')
        self.assertEqual(db.bootstrap({'user':{'id':owner},'csrf':'x'})['merchantOrders'],[])
        approved={'id':'12345','status':'approved','status_detail':'accredited','payment_method_id':'pix'}
        updated=db.apply_payment(order['id'],approved)
        self.assertEqual(updated['status'],'new');self.assertEqual(updated['paymentStatus'],'approved')
        self.assertEqual(len(db.bootstrap({'user':{'id':owner},'csrf':'x'})['merchantOrders']),1)
        with self.assertRaises(Problem) as ctx: db.payment_target(client,order['id'])
        self.assertEqual(ctx.exception.status,409)

    def test_payment_provider_method_does_not_change_original_order_method(self):
        db,client,owner,order=self._paid_fixture()
        with db.connect(True) as c:
            r=c.execute('SELECT data FROM orders WHERE id=?',(order['id'],)).fetchone();o=__import__('json').loads(r['data']);o['payment']='card';c.execute('UPDATE orders SET data=? WHERE id=?',(__import__('json').dumps(o,ensure_ascii=False,separators=(',',':')),order['id']))
        updated=db.apply_payment(order['id'],{'id':'54321','status':'approved','payment_method_id':'account_money'})
        self.assertEqual(updated['payment'],'card')
        self.assertEqual(updated['paymentProviderMethod'],'account_money')
        target=db.refund_target(owner,{'orderId':updated['id'],'expectedRevision':updated['revision'],'reason':'Teste de estorno'})
        self.assertEqual(target['providerId'],'54321')

    def test_paid_cancel_requires_verified_owner_and_records_refund_reason(self):
        db,client,owner,order=self._paid_fixture()
        order=db.apply_payment(order['id'],{'id':'12345','status':'approved','payment_method_id':'pix'})
        target=db.refund_target(owner,{'orderId':order['id'],'expectedRevision':order['revision'],'reason':'Sem ingrediente'})
        self.assertEqual(target['providerId'],'12345')
        refunded=db.apply_payment(order['id'],{'id':'12345','status':'refunded','payment_method_id':'pix'},'test-refund',target['reason'])
        self.assertEqual(refunded['status'],'cancelled');self.assertEqual(refunded['paymentStatus'],'refunded');self.assertEqual(refunded['cancellationReason'],'Sem ingrediente')

    def test_mercadopago_uses_server_total_and_idempotency(self):
        mp=FakeMP();order={'id':'PED-000001','storeName':'Loja','total':1234}
        payment=mp.create_payment(order,{'transaction_amount':0.01,'payment_method_id':'pix','payer':{'email':'a@b.com'}},'idem-1234567890123456','https://bocali.example/api/webhooks/mercadopago')
        method,path,payload,idem=mp.calls[0]
        self.assertEqual((method,path,idem),('POST','/v1/payments','idem-1234567890123456'))
        self.assertEqual(payload['transaction_amount'],12.34);self.assertEqual(payload['external_reference'],'PED-000001');self.assertEqual(payment['qr_code'],'PIX-CODE')
        mp.refund_payment('123','refund-1234567890123456');self.assertEqual(mp.calls[-1][1],'/v1/payments/123/refunds');self.assertEqual(mp.calls[-1][2],{})

    def test_card_checkout_uses_server_total_and_reuses_saved_preference(self):
        mp=FakeMP();db,client,owner,order=self._paid_fixture()
        # Change the fixture to the card path without touching any monetary snapshot.
        with db.connect(True) as c:
            r=c.execute('SELECT data FROM orders WHERE id=?',(order['id'],)).fetchone();o=__import__('json').loads(r['data']);o['payment']='card';c.execute('UPDATE orders SET data=? WHERE id=?',(__import__('json').dumps(o,ensure_ascii=False,separators=(',',':')),order['id']))
        order=db.payment_target(client,order['id'])
        pref=mp.create_checkout_preference(order,'pref-idem-1234567890','https://bocali.example/api/webhooks/mercadopago',{
            'success':'bocali://payment/success?orderId='+order['id'],'pending':'bocali://payment/pending?orderId='+order['id'],'failure':'bocali://payment/failure?orderId='+order['id']})
        method,path,payload,idem=mp.calls[-1]
        self.assertEqual((method,path,idem),('POST','/checkout/preferences','pref-idem-1234567890'))
        self.assertEqual(payload['items'][0]['unit_price'],order['total']/100)
        self.assertEqual(payload['external_reference'],order['id'])
        self.assertIn({'id':'pix'},payload['payment_methods']['excluded_payment_methods'])
        saved=db.save_checkout_preference(client,order['id'],pref,pref['sandbox_init_point'])
        self.assertFalse(saved['reused'])
        saved2=db.save_checkout_preference(client,order['id'],{'id':'PREF-OTHER'},'https://www.mercadopago.com.br/other')
        self.assertTrue(saved2['reused']);self.assertEqual(saved2['preferenceId'],'PREF-1')

    def test_webhook_signature_is_verified(self):
        db=self.db(False)
        settings=Settings('https://bocali.example',self.path,'production','', 's'*40,'',False,True,'access','public','segredo')
        app=PilotApp(settings,db)
        data_id='12345';request_id='abc-123';ts='1720000000';manifest=f'id:{data_id};request-id:{request_id};ts:{ts};'
        sig=hmac.new(b'segredo',manifest.encode(),hashlib.sha256).hexdigest()
        class R:
            def __init__(self,v):self.v=v
            def header(self,n):return {'X-Signature':f'ts={ts},v1={self.v}','X-Request-Id':request_id}.get(n,'')
        app.validate_mp_webhook(R(sig),data_id)
        with self.assertRaises(Problem):app.validate_mp_webhook(R('0'*64),data_id)

if __name__=='__main__':unittest.main(verbosity=2)
