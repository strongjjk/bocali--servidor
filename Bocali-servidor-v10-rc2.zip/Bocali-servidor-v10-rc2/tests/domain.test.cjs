'use strict';
const assert=require('node:assert/strict');
const C=require('../domain.js');
const O=require('../order-flow.js');
let passed=0;
function test(name,fn){try{fn();console.log('PASS '+name);passed++;}catch(e){console.error('FAIL '+name);throw e;}}
test('currency BR decimal',()=>assert.equal(C.moneyToCents('R$ 14,90'),1490));
test('currency thousands',()=>assert.equal(C.moneyToCents('1.234,56'),123456));
test('currency decimal point',()=>assert.equal(C.moneyToCents('14.90'),1490));
test('reject invalid/negative/zero prices',()=>{for(const v of ['','NaN','-5','0','14abc','1.000.0','1,2,3'])assert.equal(C.moneyToCents(v),null);});
test('recognize name category cents',()=>{const p=C.parseMenu('BEBIDAS\nSuco de uva R$ 8,00');assert.equal(p.items.length,1);assert.equal(p.items[0].price,800);assert.equal(p.items[0].category,'BEBIDAS');assert.equal(p.items[0].reviewed,false);});
test('ambiguous multiple prices do not auto select',()=>{const d=C.parseMenu('Pastel P R$ 12,00 G R$ 18,00').items[0];assert.equal(d.price,null);assert.equal(d.ambiguous,true);assert.equal(C.validDraft(d),false);});
test('draft requires explicit review',()=>{const d=C.parseMenu('Pastel de carne R$ 15,00').items[0];assert.equal(C.validDraft(d),false);d.reviewed=true;assert.equal(C.validDraft(d),true);});
test('no hallucinated prices',()=>assert.equal(C.parseMenu('Pastel de palmito\nConsulte nossos precos').items.length,0));
test('integer cart totals with extras',()=>{const t=C.totals({items:[{unitPrice:1490,quantity:2,extras:[{price:300}]}]},500);assert.equal(t.subtotal,3580);assert.equal(t.total,4080);});
function withCart(){const s=C.seed(),p=s.products[0];s.cart={storeId:p.storeId,items:[{id:'x',productId:p.id,name:p.name,unitPrice:p.price,extras:[],quantity:2,note:''}]};return s;}
test('checkout creates snapshot and empties cart',()=>{const s=withCart();const o=C.createOrder(s,{fulfillment:'delivery',payment:'pix'});assert.equal(o.total,3480);assert.equal(o.paymentStatus,'simulated');assert.equal(s.cart.items.length,0);s.products[0].price=3000;assert.equal(o.items[0].unitPrice,1490);});
test('duplicate click on empty cart blocked',()=>{const s=withCart();C.createOrder(s,{fulfillment:'pickup',payment:'cash'});assert.throws(()=>C.createOrder(s,{fulfillment:'pickup',payment:'cash'}));assert.equal(s.orders.length,1);});
test('paused store blocked',()=>{const s=withCart();s.stores[0].open=false;assert.throws(()=>C.createOrder(s,{fulfillment:'pickup',payment:'cash'}));});
test('unavailable product blocked',()=>{const s=withCart();s.products[0].available=false;assert.throws(()=>C.validateCart(s));});
test('changed price blocked',()=>{const s=withCart();s.products[0].price=500;assert.throws(()=>C.validateCart(s));});
test('foreign store product blocked',()=>{const s=withCart();s.cart.items[0].productId='p8';assert.throws(()=>C.validateCart(s));});
test('below minimum blocked',()=>{const s=withCart();s.stores[0].minimum=5000;assert.throws(()=>C.validateCart(s));});
test('order lifecycle and illegal transition',()=>{const s=withCart();const o=C.createOrder(s,{fulfillment:'pickup',payment:'cash'});assert.throws(()=>C.transition(o,'completed'));O.accept(o,15,25);for(const status of ['preparing','ready','completed'])C.transition(o,status);assert.equal(o.events.length,5);assert.throws(()=>C.transition(o,'cancelled'));});
test('cancel is terminal',()=>{const s=withCart();const o=C.createOrder(s,{fulfillment:'pickup',payment:'cash'});C.transition(o,'cancelled');assert.throws(()=>C.transition(o,'accepted'));});
console.log(`${passed} tests passed.`);
