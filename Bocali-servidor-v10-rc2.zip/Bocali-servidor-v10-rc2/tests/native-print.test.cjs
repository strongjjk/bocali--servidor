const test=require('node:test');const assert=require('node:assert/strict');const N=require('../native-print.js');
test('native ticket keeps server print job, payment state and exact cents',()=>{
 const o={id:'PED-000001',storeId:'cantinho',storeName:'Cantinho do Pastel',customerName:'Cliente',fulfillment:'delivery',payment:'card',paymentStatus:'approved',paymentProviderMethod:'visa',acceptedAt:'2026-09-21T15:00:00Z',createdAt:'2026-09-21T14:58:00Z',eta:{minMinutes:35,maxMinutes:55},items:[{name:'Pastel',quantity:2,unitPrice:1490,extras:[{name:'Queijo',price:300}],note:'Sem cebola'}],note:'Molho separado',delivery:{address:{street:'Rua A',number:'10',neighborhood:'Centro',city:'Pinda',state:'SP'}},subtotal:3580,fee:800,total:4380};
 const p=N.fromOrder(o,'kitchen',{id:'print_abc123',sequence:2});
 assert.equal(p.printJobId,'print_abc123');assert.equal(p.sequence,2);assert.equal(p.items[0].lineTotalCents,3580);assert.equal(p.totalCents,4380);assert.match(p.address,/Rua A/);
 assert.equal(p.testMode,false);assert.equal(p.payment,'card');assert.equal(p.paymentStatus,'approved');assert.equal(p.paymentProviderMethod,'visa');
});
test('native ticket rejects missing job',()=>assert.throws(()=>N.fromOrder({},'kitchen',null)));
