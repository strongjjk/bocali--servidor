"""Bocali identity and preservation of existing pilot data, using disposable fixtures."""
import json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests/v05'))
from pilot_app import PilotApp,Settings
from test_pilot import Client,CODE,SECRET,SETUP

class BrandTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.cfg=Settings('https://bocali.example',Path(self.tmp.name),'protected',CODE,SECRET,SETUP)
  self.app=PilotApp(self.cfg);self.c=Client(self.app)
 def tearDown(self):self.tmp.cleanup()
 def test_new_gate_brand(self):
  text=self.c.call('/')['raw'].decode();self.assertIn('Bocali | Acesso',text);self.assertIn('>bocali<span>',text);self.assertNotIn('>pede',text)
 def test_new_setup_brand(self):
  self.c.unlock();text=self.c.call('/setup')['raw'].decode();self.assertIn('Bocali | Configurar',text)
 def test_bootstrap_release_name(self):
  self.c.unlock();data=self.c.call('/api/bootstrap')['json'];self.assertEqual((data['version'],data['appName']),('0.9','Bocali'))
 def test_owner_status_release_name(self):
  self.c.setup();d=self.c.call('/api/pilot-status')['json'];self.assertEqual((d['version'],d['appName']),('0.9','Bocali'))
 def test_manifest_identity(self):
  d=json.loads((ROOT/'manifest.webmanifest').read_text());self.assertEqual(d['short_name'],'Bocali');self.assertIn('Bocali',d['name']);self.assertEqual(d['start_url'],'./#/minhas-lojas')
 def test_icon_accessible_identity(self):
  self.assertIn('<title>Bocali</title>',(ROOT/'icon.svg').read_text())
 def test_client_and_ticket_brand(self):
  s=(ROOT/'app.js').read_text();self.assertIn('aria-label="Bocali',s);self.assertIn('class="ticket-brand">bocali.',s);self.assertNotIn('nome provis',s)
 def test_login_brand(self):
  s=(ROOT/'connected.js').read_text();self.assertIn('Entrar no Bocali',s);self.assertIn('Sua conta no Bocali',s)
 def test_no_reset_of_database_name_or_schema(self):
  self.assertEqual(self.cfg.db_path.name,'pede.sqlite3')
  with self.app.db.connect() as db:self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],4)
 def test_account_and_session_survive_app_restart(self):
  self.c.setup();before=self.c.call('/api/bootstrap')['json'];self.c.app=PilotApp(self.cfg);after=self.c.call('/api/bootstrap')['json']
  self.assertEqual(before['user'],after['user']);self.assertEqual(after['managedStores'],['cantinho'])
 def test_existing_order_and_prices_survive_restart(self):
  self.c.setup();c=Client(self.app);c.customer()
  payload={'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':['cheese']}],'fulfillment':'delivery','payment':'cash','sampleIndex':1,'address':self.app.db.seed['samples'][1]['address']}
  q=c.call('/api/quote',payload);self.assertEqual(q['status'],200)
  made=c.call('/api/orders',{'quoteId':q['json']['quoteId'],'idempotencyKey':'bocali-brand-test-123456'})
  self.assertEqual(made['status'],201);before=c.call('/api/bootstrap')['json']['customerOrders']
  c.app=PilotApp(self.cfg);after=c.call('/api/bootstrap')['json']['customerOrders'];self.assertEqual(before,after);self.assertEqual(len(after),1)
 def test_preview_is_explicitly_separate(self):
  s=(ROOT/'Bocali-demonstracao-v06.html').read_text();self.assertIn('Sem conta online',s);self.assertIn('sem pedidos reais',s);self.assertIn('Bocali | Demonstracao visual 0.6',s)
 def test_protocol_preserved(self):
  self.assertIn("'X-Pede-Request'",(ROOT/'connected.js').read_text());self.assertIn("'pede-snapshot-v1'",(ROOT/'backup.py').read_text());self.assertIn("'pede-gate-v05:'",(ROOT/'pilot_app.py').read_text())
if __name__=='__main__':unittest.main()
