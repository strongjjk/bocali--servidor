"""Owned UI executed with set_content: this environment blocks URL navigation.
HTTP calls use independent requests.Session instances against the real WSGI server.
This is not a native browser-cookie/HTTPS test. Printing is stubbed.
"""
from pathlib import Path
import json,sys,tempfile,threading,re,os
import requests
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from pilot_app import PilotApp,Settings
from serve import ThreadedWSGIServer,QuietHandler
from wsgiref.simple_server import make_server
OUT=Path(os.environ.get('PEDE_TEST_OUTPUT',str(ROOT/'tests/v06/artifacts')));OUT.mkdir(parents=True,exist_ok=True)
CODE='SomenteTeste-Codigo-abcdefghijklmnopqrstuvwxyz'
SECRET='SomenteTeste-Segredo-abcdefghijklmnopqrstuvwxyz'
SETUP='SomenteTeste-Setup-abcdefghijklmnopqrstuvwxyz'
PASSWORD='SomenteTeste2026!'
checks=[]
def check(label,condition):
 if not condition:raise AssertionError(label)
 checks.append(label);print('PASS',label,flush=True)

def shot(page,name):
 page.evaluate('window.scrollTo(0,0)')
 page.wait_for_function("!document.getElementById('toast')?.classList.contains('show')",timeout=7000)
 page.wait_for_timeout(250)
 page.screenshot(path=str(OUT/name),full_page=True)

def session(base):
 s=requests.Session();s.headers.update({'Origin':base,'X-Pede-Request':'1'})
 return s

def bridge(page,s,base):
 control={'offline':False,'loseOrderResponse':False}
 def call(_source,payload):
  if control['offline']:raise RuntimeError('Simulated offline connection')
  url=payload['url']
  if not url.startswith('/api/'):raise ValueError('Only local APIs are allowed by this test harness')
  r=s.request(payload.get('method','GET'),base+url,headers=payload.get('headers',{}),data=payload.get('body'),timeout=25)
  if url=='/api/orders' and control['loseOrderResponse']:
   control['loseOrderResponse']=False
   raise RuntimeError('Simulated response loss AFTER commit')
  return {'status':r.status_code,'body':r.text,'headers':{'Content-Type':r.headers.get('Content-Type','application/json')}}
 page.expose_binding('pedeTestHttp',call)
 page.evaluate("""() => {window.fetch=async (url,o={})=>{const r=await window.pedeTestHttp({url,method:o.method||'GET',headers:o.headers||{},body:typeof o.body==='string'?o.body:null});return new Response(r.body,{status:r.status,headers:r.headers});};} """)
 return control

def mount_app(context,s,base,route='#/conta'):
 page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 css='\n'.join((ROOT/n).read_text() for n in ['styles.css','delivery.css','connected.css','operations.css'])
 page.set_content('<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style></head><body><div id="app"></div><div id="toast" role="status"></div><dialog id="modal" aria-labelledby="modal-title"></dialog></body></html>')
 control=bridge(page,s,base)
 data=s.get(base+'/api/bootstrap').json()
 page.evaluate('(d)=>window.PedeBootstrap=d',data)
 page.evaluate('(h)=>location.hash=h',route)
 for name in ['delivery.js','domain.js','order-flow.js','app.js','delivery-ui.js','connected.js','operations.js']:
  page.add_script_tag(content=(ROOT/name).read_text())
 page.wait_for_timeout(150)
 return page,control,errors

def mount_entry(context,name,s,base):
 page=context.new_page();html=(ROOT/(name+'.html')).read_text()
 html=re.sub(r'<script\b[^>]*>.*?</script>','',html,flags=re.S)
 html=re.sub(r'<link\b[^>]*>','',html)
 html=html.replace('</head>','<style>'+(ROOT/'pilot.css').read_text()+'</style></head>')
 page.set_content(html);bridge(page,s,base);page.add_script_tag(content=(ROOT/(name+'.js')).read_text())
 return page

def login(page,email):
 page.locator('[name=email]').fill(email);page.locator('[name=password]').fill(PASSWORD)
 page.locator('#account-form [type=submit]').click();page.wait_for_function('Boolean(Net.user)');page.wait_for_timeout(200)

with tempfile.TemporaryDirectory() as tmp:
 srv=make_server('127.0.0.1',0,lambda e,r:[],server_class=ThreadedWSGIServer,handler_class=QuietHandler)
 base='http://127.0.0.1:'+str(srv.server_port)
 app=PilotApp(Settings(base,Path(tmp),'local',CODE,SECRET,SETUP))
 srv.set_app(app);threading.Thread(target=srv.serve_forever,daemon=True).start()
 try:
  with sync_playwright() as p:
   browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
   owner=session(base)
   entry=mount_entry(browser.new_context(viewport={'width':1440,'height':970}),'pilot',owner,base)
   shot(entry,'entrada-desktop.png')
   check('Private gate has no horizontal overflow',entry.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   entry.locator('#pilot-code').fill('CodigoErrado-abcdefghijklmnopqrstuv')
   entry.locator('button[type=submit]').click();entry.wait_for_function("document.querySelector('#entry-error').textContent.length>0")
   check('Wrong access code is shown as an error', 'invalido' in entry.locator('#entry-error').inner_text())
   mobile=mount_entry(browser.new_context(viewport={'width':390,'height':844}),'pilot',session(base),base)
   shot(mobile,'entrada-celular.png')
   check('Mobile private gate has no horizontal overflow',mobile.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   # Successful redirects are not emulated: API is tested over real HTTP, screen is mounted separately.
   check('Gate unlock HTTP succeeds',owner.post(base+'/api/pilot-unlock',json={'code':CODE}).status_code==200)
   setup=mount_entry(browser.new_context(viewport={'width':900,'height':1060}),'setup',owner,base)
   shot(setup,'configurar-responsavel.png')
   setup.locator('[name=setupToken]').fill(SETUP);setup.locator('[name=name]').fill('Balcao teste');setup.locator('[name=email]').fill('owner@example.com')
   setup.locator('[name=password]').fill(PASSWORD);setup.locator('[name=repeat]').fill(PASSWORD+'wrong')
   setup.locator('button[type=submit]').click()
   check('Setup blocks mismatched passwords in UI','nao conferem' in setup.locator('#entry-error').inner_text())
   created=owner.post(base+'/api/setup-owner',json={'setupToken':SETUP,'name':'Balcao de teste','email':'owner@example.com','password':PASSWORD})
   check('Initial owner configuration over HTTP succeeds',created.status_code==201)
   merchant,mc,me=mount_app(browser.new_context(viewport={'width':1512,'height':1120}),owner,base,'#/piloto')
   merchant.wait_for_function('Boolean(Ops.data)')
   check('Preparation panel loads real server configuration',merchant.locator('h1').inner_text()=='Preparar o teste.')
   check('Local URL is not offered as a public share link',merchant.locator('[data-ops=copy]').is_disabled())
   check('Payments are explicitly simulated','Simulados' in merchant.locator('#main').inner_text())
   shot(merchant,'preparar-teste-desktop.png')
   merchant.set_viewport_size({'width':390,'height':844});shot(merchant,'preparar-teste-celular.png')
   check('Mobile preparation panel has no horizontal overflow',merchant.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   merchant.set_viewport_size({'width':1512,'height':1040});merchant.evaluate("location.hash='#/painel'")
   client=session(base);client.post(base+'/api/pilot-unlock',json={'code':CODE})
   customer,cc,ce=mount_app(browser.new_context(viewport={'width':390,'height':844}),client,base)
   shot(customer,'conta-celular.png')
   customer.locator('[data-net=auth-mode][data-mode=register]').click()
   customer.locator('[name=name]').fill('Cliente de teste');customer.locator('[name=email]').fill('client@example.com');customer.locator('[name=password]').fill(PASSWORD)
   customer.locator('#account-form [type=submit]').click();customer.wait_for_function('Boolean(Net.user)')
   check('Customer registration works through WSGI server',customer.evaluate('Net.managedStores.length===0'))
   customer.evaluate("location.hash='#/loja/cantinho'")
   customer.wait_for_selector('[data-action=product][data-id=p0]');shot(customer,'cardapio-celular.png')
   customer.locator('[data-action=product][data-id=p0]').click();customer.locator('[data-extra=cheese]').check();customer.locator('[data-action=add-cart]').click()
   customer.evaluate('checkout()');customer.locator('[data-geo=checkout-sample][data-index="1"]').click();customer.locator('[data-geo=confirm-address]').click()
   customer.locator('#place-order').click();customer.wait_for_selector('[data-net=confirm-order]')
   check('Server total is R$ 25,90 including delivery','25,90' in customer.locator('#modal').inner_text())
   shot(customer,'pedido-confirmacao-celular.png')
   cc['loseOrderResponse']=True;customer.locator('[data-net=confirm-order]').click()
   customer.wait_for_function("document.querySelector('#confirm-order-error')?.textContent.length>0")
   with app.db.connect() as db:count=db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
   check('Lost response does not hide that confirmation is uncertain',count==1)
   customer.locator('[data-net=confirm-order]').click();customer.wait_for_selector('[data-action=goto-orders]')
   with app.db.connect() as db:count=db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
   check('Retry after lost response creates no duplicate order',count==1)
   oid=customer.locator('#modal .success h2').inner_text();customer.locator('[data-action=goto-orders]').click()
   merchant.wait_for_selector(f'[data-order-id="{oid}"]',timeout=10000)
   check('Same order reaches separate merchant session',True)
   merchant.locator(f'[data-action=accept-order][data-id="{oid}"]').click();merchant.locator('#eta-min').fill('35');merchant.locator('#eta-max').fill('55');merchant.locator('#accept-print').uncheck()
   merchant.locator('#confirm-accept').click();customer.wait_for_function('(id)=>Net.customerOrders.some(o=>o.id===id&&o.eta?.minMinutes===35)',arg=oid,timeout=12000)
   check('Acceptance and 35-55 minute ETA reach customer',True)
   shot(customer,'prazo-celular.png')
   merchant.evaluate("window.print=()=>{window.testPrints=(window.testPrints||0)+1;window.dispatchEvent(new Event('afterprint'));}")
   shot(merchant,'aceitador-desktop.png')
   merchant.locator(f'[data-action=receipt][data-kind=kitchen][data-id="{oid}"]').click()
   check('Kitchen ticket carries Bocali identity',merchant.locator('.kitchen-ticket .ticket-brand').inner_text()=='bocali.')
   merchant.locator('.kitchen-ticket').screenshot(path=str(OUT/'comanda-cozinha.png'))
   merchant.locator('[data-action=print-order]').click();merchant.wait_for_function('window.testPrints===1')
   merchant.locator('[data-action=print-result][data-success=true]').click();merchant.wait_for_function('(id)=>Net.merchantOrders.find(o=>o.id===id).printJobs[0].status==="confirmed_by_operator"',arg=oid)
   check('Operator confirmation of simulated print is persisted',True)
   merchant.locator('[data-action=close-modal]').click()
   cc['offline']=True
   customer.evaluate("refresh().catch(()=>updateConnection())")
   check('Simulated network loss displays offline status',customer.evaluate('Net.online===false'))
   cc['offline']=False;customer.evaluate('refresh()');customer.wait_for_function('Net.online===true')
   with app.db.connect() as db:count=db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
   check('Reconnection refreshes without sending a new order',count==1)
   customer.evaluate("location.hash='#/piloto'");customer.wait_for_selector('h1')
   check('Customer cannot open preparation panel','Este acesso' in customer.locator('h1').inner_text())
   check('No unexpected JavaScript errors in app screens',not me and not ce)
   check('Entry has new accessible title',mobile.title().startswith('Bocali'))
   check('Initial setup page has new title',setup.title().startswith('Bocali'))
   check('Customer browser title uses Bocali',customer.title().startswith('Bocali'))
   check('Customer visible interface has no old brand',not re.search(r"\bPede\b|\bpede\.",customer.locator('body').inner_text()))
   merchant.evaluate("location.hash='#/areas'");merchant.wait_for_timeout(300)
   shot(merchant,'mapa-taxas-desktop.png')
   check('Merchant visible interface has no old brand',not re.search(r"\bPede\b|\bpede\.",merchant.locator('body').inner_text()))
   for width in (320,390,768,1440):
    merchant.set_viewport_size({'width':width,'height':1000})
    check('Merchant map no horizontal overflow at '+str(width),merchant.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   customer.evaluate("location.hash='#/minhas-lojas'");customer.wait_for_timeout(200)
   for width in (320,390,768,1440):
    customer.set_viewport_size({'width':width,'height':900})
    check('Customer home no horizontal overflow at '+str(width),customer.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   preview=browser.new_page(viewport={'width':1440,'height':1024})
   preview_errors=[];preview.on('pageerror',lambda e:preview_errors.append(str(e)))
   preview.set_content((ROOT/'Bocali-demonstracao-v06.html').read_text());preview.wait_for_selector('.logo')
   check('Standalone preview shows Bocali',preview.locator('.logo').first.inner_text()=='bocali.')
   check('Standalone preview has explicit local-only notice','Sem conta online' in preview.locator('.preview-notice').inner_text())
   shot(preview,'previa-home-desktop.png')
   preview.set_viewport_size({'width':390,'height':844});shot(preview,'previa-home-celular.png')
   check('Standalone preview mobile no overflow',preview.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   preview.evaluate("location.hash='#/loja/cantinho'");preview.wait_for_selector('[data-action=product][data-id=p0]')
   preview.locator('[data-action=product][data-id=p0]').click();preview.locator('[data-action=add-cart]').click()
   check('Standalone preview can add item to cart',preview.evaluate('state.cart.items.length===1'))
   check('Standalone preview has no JavaScript errors',not preview_errors)
   browser.close()
 finally:srv.shutdown();srv.server_close()
(OUT/'browser-results.json').write_text(json.dumps({'count':len(checks),'checks':checks,
 'transport':'set_content + independent requests.Session to real local WSGI HTTP server; native URL navigation blocked by environment',
 'limitations':['Native cookies, loading by URL and HTTPS not validated','No physical devices, payment, geocoding or printer test','Printing replaced with stub','Network response loss intentionally injected by harness']},indent=2))
