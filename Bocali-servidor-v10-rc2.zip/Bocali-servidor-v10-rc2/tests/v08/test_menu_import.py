import io
import unittest
from pathlib import Path
from pypdf import PdfWriter

from menu_parser import parse_menu_text
from pdf_service import extract_pdf

ROOT = Path(__file__).resolve().parents[2]


class MenuParserTests(unittest.TestCase):
    def test_categories_and_prices(self):
        result = parse_menu_text('''ESPECIAIS\nPastel de palmito R$ 18,90\nPastel de calabresa 17,50\nBEBIDAS\nSuco de uva 300 ml R$ 8,00''')
        self.assertEqual([i['price'] for i in result['items']], [1890, 1750, 800])
        self.assertEqual([i['category'] for i in result['items']], ['ESPECIAIS', 'ESPECIAIS', 'BEBIDAS'])
        self.assertEqual(result['summary']['highConfidence'], 3)

    def test_multiple_prices_stays_ambiguous(self):
        result = parse_menu_text('PIZZAS\nMussarela P R$ 35,00 G R$ 55,00')
        item = result['items'][0]
        self.assertTrue(item['ambiguous'])
        self.assertIsNone(item['price'])
        self.assertEqual(item['priceOptions'], [3500, 5500])
        self.assertEqual(item['confidence'], 'low')

    def test_generic_uppercase_heading(self):
        result = parse_menu_text('PRATOS EXECUTIVOS\nFrango grelhado R$ 29,90')
        self.assertEqual(result['items'][0]['category'], 'PRATOS EXECUTIVOS')

    def test_pdf_example_builds_structured_draft(self):
        data = (ROOT / 'examples' / 'cardapio-exemplo.pdf').read_bytes()
        result = extract_pdf(data)
        self.assertEqual(result['pages'], 1)
        self.assertGreaterEqual(result['summary']['items'], 3)
        names = [x['name'] for x in result['items']]
        self.assertIn('Pastel de palmito', names)
        self.assertIn('Suco de uva 300 ml', names)

    def test_image_only_or_blank_pdf_is_not_guessed(self):
        out = io.BytesIO()
        writer = PdfWriter(); writer.add_blank_page(width=300, height=300); writer.write(out)
        with self.assertRaisesRegex(ValueError, 'imagens'):
            extract_pdf(out.getvalue())

    def test_invalid_file_rejected(self):
        with self.assertRaisesRegex(ValueError, 'cabecalho PDF'):
            extract_pdf(b'not a pdf')


if __name__ == '__main__':
    unittest.main()
