import json,sys,tempfile,threading,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import requests
from backend import Database
from server import make_server

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.db=Database(Path(cls.tmp.name)/'test.sqlite3',ROOT/'seed.json')
        cls.db.setup_owner('owner@example.com','SomenteTeste2026!')
        cls.srv=make_server('127.0.0.1',0,cls.db);cls.base='http://127.0.0.1:'+str(cls.srv.server_address[1])
        cls.thread=threading.Thread(target=cls.srv.serve_forever,daemon=True);cls.thread.start()

    @classmethod
    def tearDownClass(cls):cls.srv.shutdown();cls.srv.server_close();cls.tmp.cleanup()

    def client(self,login=True):
        s=requests.Session();s.headers.update({'Origin':self.base,'X-Pede-Request':'1'})
        if login:
            self.assertEqual(s.post(self.base+'/api/login',json={'email':'owner@example.com','password':'SomenteTeste2026!'}).status_code,200)
            boot=s.get(self.base+'/api/bootstrap').json();s.headers['X-CSRF-Token']=boot['csrf']
        return s

    def test_http_login_cookie_flags(self):
        s=self.client(False);r=s.post(self.base+'/api/login',json={'email':'owner@example.com','password':'SomenteTeste2026!'})
        cookie=r.headers['Set-Cookie'];self.assertIn('HttpOnly',cookie);self.assertIn('SameSite=Lax',cookie);self.assertNotIn('password',r.text);self.assertNotIn('Somente',r.text)

    def test_unauthenticated_write_denied(self):
        r=self.client(False).post(self.base+'/api/orders',json={});self.assertEqual(r.status_code,401)

    def test_csrf_token_required(self):
        s=self.client();s.headers.pop('X-CSRF-Token');r=s.post(self.base+'/api/favorites',json={'storeId':'cantinho','saved':True});self.assertEqual(r.status_code,403)

    def test_cross_origin_blocked(self):
        s=self.client(False);s.headers['Origin']='https://untrusted.example';r=s.post(self.base+'/api/login',json={});self.assertEqual(r.status_code,403)

    def test_custom_request_header_required(self):
        s=self.client(False);s.headers.pop('X-Pede-Request');self.assertEqual(s.post(self.base+'/api/login',json={}).status_code,403)

    def test_sources_and_database_not_downloadable(self):
        for path in ['/backend.py','/server.py','/seed.json','/data/pede.sqlite3','/legacy/server-v03.py','/requirements.txt','/%2e%2e/backend.py']:
            with self.subTest(path=path):self.assertEqual(requests.get(self.base+path).status_code,404)

    def test_foreign_host_blocked(self):
        self.assertEqual(requests.get(self.base+'/api/bootstrap',headers={'Host':'evil.example'}).status_code,403)

    def test_bootstrap_not_cached(self):
        r=self.client().get(self.base+'/api/bootstrap');self.assertEqual(r.headers['Cache-Control'],'no-store');self.assertIn("frame-ancestors 'none'",r.headers['Content-Security-Policy'])

    def test_complete_order_roundtrip(self):
        s=self.client();q=s.post(self.base+'/api/quote',json={'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':[]}],'fulfillment':'pickup','payment':'cash'});self.assertEqual(q.status_code,200)
        r=s.post(self.base+'/api/orders',json={'quoteId':q.json()['quoteId'],'idempotencyKey':'http-roundtrip-key001'});self.assertEqual(r.status_code,201);oid=r.json()['order']['id']
        p=s.post(self.base+'/api/order-action',json={'orderId':oid,'expectedRevision':1,'action':'accept','min':15,'max':25});self.assertEqual(p.status_code,200);self.assertEqual(p.json()['order']['eta']['minMinutes'],15)

    def test_logout_invalidates_cookie_session(self):
        s=self.client();self.assertEqual(s.post(self.base+'/api/logout',json={}).status_code,200);self.assertIsNone(s.get(self.base+'/api/bootstrap').json()['user'])

    def test_pdf_extract_still_available_to_merchant(self):
        s=self.client();data=(ROOT/'examples/cardapio-exemplo.pdf').read_bytes();r=s.post(self.base+'/api/import-pdf',data=data,headers={'Content-Type':'application/pdf'});self.assertEqual(r.status_code,200,r.text);self.assertGreater(len(r.json()['text']),10)

    def test_invalid_pdf_is_rejected(self):
        r=self.client().post(self.base+'/api/import-pdf',data=b'not a pdf',headers={'Content-Type':'application/pdf'});self.assertEqual(r.status_code,422)

    def test_ui_files_are_served(self):
        for path in ['/','/loader.js','/connected.js','/connected.css']:
            self.assertEqual(requests.get(self.base+path).status_code,200)

    def test_registration_does_not_claim_existing_store(self):
        s=self.client(False);r=s.post(self.base+'/api/register',json={'name':'Lojista teste','email':'new@example.com','password':'SomenteTeste2026!','mode':'merchant','storeName':'Loja nova','storeId':'cantinho','role':'superadmin'});self.assertEqual(r.status_code,201)
        d=s.get(self.base+'/api/bootstrap').json();self.assertEqual(len(d['managedStores']),1);self.assertNotIn('cantinho',d['managedStores'])

if __name__=='__main__':unittest.main(verbosity=2)
