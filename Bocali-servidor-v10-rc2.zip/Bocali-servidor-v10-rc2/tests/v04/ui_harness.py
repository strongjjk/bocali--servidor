"""Run owned UI code without URL navigation; transport uses the local test server.
The environment's browser URL policy is unchanged. HTTP security is tested separately.
"""
import json,os
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[2]
BASE=os.environ.get('PEDE_TEST_BASE','http://127.0.0.1:8000')

def mount(context,hash='#/conta'):
    session=requests.Session()
    session.headers.update({'Origin':BASE})
    page=context.new_page()
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    def bridge(_source,payload):
        url=payload['url']
        if not url.startswith('/api/'):raise ValueError('Only local API calls are supported by the UI harness')
        method=payload.get('method','GET')
        headers=payload.get('headers',{})
        data=payload.get('body')
        response=session.request(method,BASE+url,headers=headers,data=data,timeout=30)
        return {'status':response.status_code,'body':response.text,'headers':{'Content-Type':response.headers.get('Content-Type','application/json')}}
    page.expose_binding('pedeHttp',bridge)
    css=(ROOT/'styles.css').read_text()+(ROOT/'delivery.css').read_text()+(ROOT/'connected.css').read_text()
    page.set_content('<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style></head><body><div id="app"></div><div id="toast" role="status"></div><dialog id="modal" aria-labelledby="modal-title"></dialog></body></html>')
    page.evaluate('''() => {window.fetch=async (url,opts={})=>{const r=await window.pedeHttp({url,method:opts.method||'GET',headers:opts.headers||{},body:typeof opts.body==='string'?opts.body:null});return new Response(r.body,{status:r.status,headers:r.headers});};}''')
    boot=session.get(BASE+'/api/bootstrap').json()
    page.evaluate('(b)=>window.PedeBootstrap=b',boot)
    page.evaluate('(h)=>location.hash=h',hash)
    for name in ['delivery.js','domain.js','order-flow.js','app.js','delivery-ui.js','connected.js']:
        page.add_script_tag(content=(ROOT/name).read_text())
    page.wait_for_timeout(150)
    return page,session,errors

def login(page,email):
    page.locator('[name=email]').fill(email)
    page.locator('[name=password]').fill('SomenteTeste2026!')
    page.locator('#account-form [type=submit]').click()
    page.wait_for_function("Boolean(Net.user)")
    page.wait_for_timeout(250)
