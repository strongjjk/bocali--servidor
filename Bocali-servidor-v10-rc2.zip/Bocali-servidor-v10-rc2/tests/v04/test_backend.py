"""Deterministic tests. No real customer data, geocoder requests or payments."""
from __future__ import annotations
import copy,json,sys,tempfile,time,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from backend import Database,Problem,area_quote,clean_zone
PASSWORD='SomenteTeste2026!'

class PilotTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.template=tempfile.TemporaryDirectory()
        db=Database(Path(cls.template.name)/'template.sqlite3',ROOT/'seed.json')
        db.setup_owner('balcao@example.com',PASSWORD,'Balcao teste')
        for email in ['cliente@example.com','outra@example.com']:
            db.register({'email':email,'password':PASSWORD,'name':email.split('@')[0]})
        token=db.register({'email':'loja@example.com','password':PASSWORD,'name':'Outra loja','mode':'merchant','storeName':'Loja separada'})
        with db.connect() as c:
            cls.uids={r['email']:r['id'] for r in c.execute('SELECT id,email FROM users')}
            cls.other_store=c.execute('SELECT store_id FROM members WHERE user_id=?',(cls.uids['loja@example.com'],)).fetchone()[0]
        import sqlite3
        with sqlite3.connect(db.path) as source,sqlite3.connect(Path(cls.template.name)/'copy.sqlite3') as dest:source.backup(dest)

    @classmethod
    def tearDownClass(cls):cls.template.cleanup()

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();path=Path(self.tmp.name)/'test.sqlite3'
        import shutil;shutil.copy2(Path(self.template.name)/'copy.sqlite3',path)
        self.db=Database(path,ROOT/'seed.json');self.uid=self.uids['cliente@example.com'];self.owner=self.uids['balcao@example.com']

    def tearDown(self):self.tmp.cleanup()

    def payload(self,mode='delivery',sample=1):
        return {'storeId':'cantinho','items':[{'productId':'p0','quantity':1,'extraIds':['cheese'],'note':'Sem azeitona'}],'fulfillment':mode,'payment':'cash','address':self.db.seed['samples'][sample]['address'],'sampleIndex':sample}

    def order(self,mode='delivery'):
        q=self.db.quote(self.uid,self.payload(mode));return self.db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'test-create-000000001'})['order']

    def catalog(self):
        with self.db.connect() as c:
            store=self.db.store(c,'cantinho');products=[json.loads(r['data']) for r in c.execute('SELECT data FROM products WHERE store_id=?',('cantinho',))]
        return {'storeId':'cantinho','expectedVersion':store['version'],'store':store,'products':products}

    def expect_problem(self,status,fn):
        with self.assertRaises(Problem) as ctx:fn()
        self.assertEqual(ctx.exception.status,status)

    def test_passwords_are_argon_hashes(self):
        with self.db.connect() as c:row=c.execute('SELECT password_hash FROM users LIMIT 1').fetchone()
        self.assertTrue(row[0].startswith('$argon2id$'));self.assertNotIn(PASSWORD,row[0])

    def test_login_rejects_wrong_password(self):
        self.expect_problem(401,lambda:self.db.login({'email':'cliente@example.com','password':'senha errada'}))

    def test_session_logout_invalidates(self):
        t=self.db.login({'email':'cliente@example.com','password':PASSWORD});self.assertIsNotNone(self.db.session(t));self.db.logout(t);self.assertIsNone(self.db.session(t))

    def test_expired_session_denied(self):
        from backend import digest
        t=self.db.login({'email':'cliente@example.com','password':PASSWORD})
        with self.db.connect(True) as c:c.execute('UPDATE sessions SET expires=0 WHERE token_hash=?',(digest(t),))
        self.assertIsNone(self.db.session(t))

    def test_public_bootstrap_has_no_private_data(self):
        self.order();d=self.db.bootstrap(None)
        self.assertEqual(d['customerOrders'],[]);self.assertEqual(d['merchantOrders'],[]);self.assertEqual(d['favorites'],[]);self.assertIsNone(d['csrf'])
        self.assertNotIn('password_hash',json.dumps(d));self.assertNotIn('customerName',json.dumps(d))

    def test_customer_histories_are_isolated(self):
        self.order();d=self.db.bootstrap({'user':{'id':self.uids['outra@example.com']},'csrf':'x'})
        self.assertEqual(d['customerOrders'],[]);self.assertEqual(d['merchantOrders'],[])

    def test_merchant_does_not_own_seed_store(self):
        d=self.db.bootstrap({'user':{'id':self.uids['loja@example.com']},'csrf':'x'})
        self.assertEqual(d['managedStores'],[self.other_store]);self.assertNotIn('cantinho',d['managedStores'])

    def test_foreign_catalog_rejected(self):
        self.expect_problem(403,lambda:self.db.catalog(self.uids['loja@example.com'],self.catalog()))

    def test_cross_store_product_collision_rejected(self):
        data=self.catalog();data['products'][0]['id']='p8'
        self.expect_problem(403,lambda:self.db.catalog(self.owner,data))

    def test_price_and_fee_client_tampering_ignored(self):
        p=self.payload();p.update({'total':1,'fee':0,'paymentStatus':'paid'});p['items'][0]['unitPrice']=0
        o=self.db.quote(self.uid,p)['order'];self.assertEqual(o['subtotal'],1790);self.assertEqual(o['fee'],800);self.assertEqual(o['total'],2590);self.assertEqual(o['paymentStatus'],'simulated')

    def test_pickup_has_zero_delivery(self):
        self.assertEqual(self.db.quote(self.uid,self.payload('pickup'))['order']['fee'],0)

    def test_sample_rates_a_b_c(self):
        self.assertEqual([self.db.quote(self.uid,self.payload(sample=i))['order']['fee'] for i in range(3)],[500,800,1200])

    def test_outside_area_is_blocked(self):
        self.expect_problem(422,lambda:self.db.quote(self.uid,self.payload(sample=3)))

    def test_forged_address_is_rejected(self):
        p=self.payload();p['address']=copy.deepcopy(p['address']);p['address']['street']='Outro endereco'
        self.expect_problem(409,lambda:self.db.quote(self.uid,p))

    def test_sample_addresses_can_be_disabled(self):
        self.db.allow_samples=False;self.expect_problem(403,lambda:self.db.quote(self.uid,self.payload()))

    def test_invented_geocoder_token_rejected(self):
        p=self.payload();p.pop('sampleIndex');p['addressToken']='not-a-real-token'
        self.expect_problem(409,lambda:self.db.quote(self.uid,p))

    def test_geocoder_tokens_are_account_bound(self):
        result=copy.deepcopy(self.db.seed['samples'][1]);result['source']='geoapify'
        token=self.db.add_geocodes(self.uid,[result])[0]['addressToken'];p=self.payload();p.pop('sampleIndex');p['addressToken']=token
        self.assertEqual(self.db.quote(self.uid,p)['order']['fee'],800)
        self.expect_problem(409,lambda:self.db.quote(self.uids['outra@example.com'],p))

    def test_extras_cannot_be_duplicated(self):
        p=self.payload();p['items'][0]['extraIds']=['cheese','cheese'];self.expect_problem(400,lambda:self.db.quote(self.uid,p))

    def test_product_from_another_store_rejected(self):
        p=self.payload();p['items'][0]['productId']='p8';self.expect_problem(422,lambda:self.db.quote(self.uid,p))

    def test_unavailable_product_rejected(self):
        data=self.catalog();data['products'][0]['available']=False;self.db.catalog(self.owner,data)
        self.expect_problem(409,lambda:self.db.quote(self.uid,self.payload()))

    def test_closed_store_rejected(self):
        data=self.catalog();data['store']['open']=False;self.db.catalog(self.owner,data)
        self.expect_problem(409,lambda:self.db.quote(self.uid,self.payload()))

    def test_idempotency_prevents_duplicate_orders(self):
        q=self.db.quote(self.uid,self.payload());p={'quoteId':q['quoteId'],'idempotencyKey':'repeated-send-00001'}
        a=self.db.create_order(self.uid,p);b=self.db.create_order(self.uid,p)
        self.assertEqual(a['order']['id'],b['order']['id']);self.assertTrue(b['reused'])

    def test_quote_consumed_once_with_different_keys(self):
        q=self.db.quote(self.uid,self.payload());a=self.db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'first-key-00000001'});b=self.db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'second-key-0000002'})
        self.assertEqual(a['order']['id'],b['order']['id'])

    def test_concurrent_duplicate_submissions(self):
        q=self.db.quote(self.uid,self.payload());payload={'quoteId':q['quoteId'],'idempotencyKey':'parallel-send-00001'}
        with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(lambda _:self.db.create_order(self.uid,payload),range(4)))
        self.assertEqual(len({x['order']['id'] for x in results}),1)

    def test_quote_expiration(self):
        q=self.db.quote(self.uid,self.payload())
        with self.db.connect(True) as c:c.execute('UPDATE quotes SET expires=0 WHERE id=?',(q['quoteId'],))
        self.expect_problem(409,lambda:self.db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'expired-key-00001'}))

    def test_changed_price_requires_new_confirmation(self):
        q=self.db.quote(self.uid,self.payload());data=self.catalog();data['products'][0]['price']+=100;self.db.catalog(self.owner,data)
        self.expect_problem(409,lambda:self.db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'changed-price-0001'}))

    def test_old_orders_keep_recorded_rate(self):
        o=self.order();data=self.catalog();data['store']['deliveryConfig']['zones'][1]['fee']=1100;self.db.catalog(self.owner,data)
        with self.db.connect() as c:saved=json.loads(c.execute('SELECT data FROM orders WHERE id=?',(o['id'],)).fetchone()[0])
        self.assertEqual(saved['fee'],800);self.assertEqual(self.db.quote(self.uid,self.payload())['order']['fee'],1100)

    def test_catalog_optimistic_conflict(self):
        p=self.catalog();self.db.catalog(self.owner,p);self.expect_problem(409,lambda:self.db.catalog(self.owner,p))

    def test_foreign_order_action_rejected(self):
        o=self.order();self.expect_problem(403,lambda:self.db.action(self.uids['loja@example.com'],{'orderId':o['id'],'expectedRevision':1,'action':'accept','min':30,'max':50}))

    def test_acceptance_and_revision_conflicts(self):
        o=self.order();p={'orderId':o['id'],'expectedRevision':1,'action':'accept','min':30,'max':50};a=self.db.action(self.owner,p)['order']
        self.assertEqual(a['status'],'accepted');self.assertEqual(a['eta']['minMinutes'],30);self.expect_problem(409,lambda:self.db.action(self.owner,p))

    def test_pickup_cannot_be_dispatched(self):
        o=self.order('pickup')
        for p in [{'action':'accept','min':15,'max':25},{'action':'status','to':'preparing'},{'action':'status','to':'ready'}]:o=self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],**p})['order']
        self.expect_problem(409,lambda:self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'status','to':'dispatched'}))

    def test_print_pending_requires_confirmation(self):
        o=self.order();o=self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':1,'action':'accept','min':30,'max':50})['order'];o=self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'print','kind':'kitchen','paper':80})['order']
        self.expect_problem(409,lambda:self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'print','kind':'kitchen','paper':80}))
        j=o['printJobs'][0];o=self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'print-result','jobId':j['id'],'success':True})['order'];self.assertEqual(o['printJobs'][0]['status'],'confirmed_by_operator')

    def test_cancellation_requires_reason(self):
        o=self.order();self.expect_problem(400,lambda:self.db.action(self.owner,{'orderId':o['id'],'expectedRevision':o['revision'],'action':'status','to':'cancelled','reason':''}))

    def test_restart_preserves_orders_and_ids(self):
        o=self.order();new_db=Database(self.db.path,ROOT/'seed.json')
        q=new_db.quote(self.uid,self.payload());second=new_db.create_order(self.uid,{'quoteId':q['quoteId'],'idempotencyKey':'after-restart-00001'})['order'];self.assertNotEqual(o['id'],second['id'])
        with new_db.connect() as c:self.assertEqual(c.execute('SELECT count(*) FROM orders').fetchone()[0],2)

    def test_blocked_zone_has_precedence(self):
        data=self.catalog();z=copy.deepcopy(data['store']['deliveryConfig']['zones'][1]);z['id']='blocked';z['kind']='blocked';z['priority']=0;data['store']['deliveryConfig']['zones'].append(z);self.db.catalog(self.owner,data)
        self.expect_problem(422,lambda:self.db.quote(self.uid,self.payload()))

    def test_overlap_priority_conflict_blocked(self):
        data=self.catalog();data['store']['deliveryConfig']['zones'][2]['priority']=20;self.db.catalog(self.owner,data)
        self.expect_problem(422,lambda:self.db.quote(self.uid,self.payload()))

    def test_malformed_polygon_rejected(self):
        z=copy.deepcopy(self.db.seed['stores'][0]['deliveryConfig']['zones'][0]);z['ring']=[[0,0],[1,1],[1,0],[0,1]]
        self.expect_problem(400,lambda:clean_zone(z,'cantinho'))

    def test_favorites_account_bound(self):
        self.db.favorites(self.uid,{'storeId':'cantinho','saved':True});d=self.db.bootstrap({'user':{'id':self.uids['outra@example.com']},'csrf':'x'});self.assertEqual(d['favorites'],[])

if __name__=='__main__':unittest.main(verbosity=2)
