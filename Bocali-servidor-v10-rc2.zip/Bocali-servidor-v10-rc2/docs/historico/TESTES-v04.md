# Verificações da versão 0.4

## Resultado desta execução

52 testes automatizados de regras/HTTP passaram. 16 verificações do fluxo de interface passaram. Os testes puros anteriores de domínio, aceite/impressão e geometria também foram reexecutados. Resultados textuais e JSON estão em `tests/v04/`.

Cenários cobertos: senhas por hash, login incorreto, expiração e saída; isolamento entre clientes e lojistas; bloqueio de acesso a fontes/banco; origem, CSRF e atributos de cookie; cotação com preços adulterados no cliente; adicionais duplicados; retirada; áreas A/B/C, sobreposição, bloqueios e fora da cobertura; endereço alterado e identificador de geocodificação vinculado à conta; loja pausada e produto indisponível; repetição/concorrrência no envio; expiração da cotação; preservação de valores de pedidos anteriores; versões concorrentes; aceite, prazo, retirada, cancelamento, registro de impressão; persistência em reabertura do banco; PDF válido/inválido.

Na interface, contas separadas de cliente e lojista realizaram um pedido, visualizaram o prazo confirmado e registraram a conferência de impressão. Também foram testados alteração de cardápio, revisão da importação e cadastro de uma loja independente, inicialmente pausada e vazia.

## Como os testes de interface foram executados

O navegador deste ambiente bloqueia navegação por URL. Essa política não foi alterada. O código da interface foi executado com `set_content` em contextos isolados do Chromium; uma ponte de teste encaminhou suas chamadas ao servidor HTTP local real usando sessões separadas. O carregamento nativo do site, cookies no navegador, persistência de sessionStorage, transporte HTTPS e comportamento em aparelhos físicos ainda precisam de validação normal.

A chamada `window.print` foi substituída por uma função de teste. Nenhuma impressora, pagamento ou serviço de mensagens foi acionado. O adaptador de geocodificação foi testado com resultados artificiais, sem consulta a endereços reais. O script Windows não foi executado.

## Reproduzir

```sh
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests/v04 -p "test_*.py" -v
node tests/domain.test.cjs
node tests/order-flow.test.cjs
node tests/delivery.test.cjs
# A primeira instalação de navegador do Playwright pode exigir:
python -m playwright install chromium
python tests/v04/browser_flow.py
```

O teste de interface cria banco e contas temporários. Os endereços de e-mail `example.com` e a senha visível nos testes são apenas fixtures locais; não são contas ativas de um serviço publicado. Um caminho de navegador existente pode ser informado em `CHROMIUM_PATH`. Os arquivos de teste não alteram o banco normal de `data/`.

Antes de lançar: testes nativos no computador e celular do piloto, queda de rede, retomada de sessão, impressão real, carga, restauração de backup, serviço de endereços e pagamentos continuam necessários. Passar os testes listados não significa estar pronto para produção.
