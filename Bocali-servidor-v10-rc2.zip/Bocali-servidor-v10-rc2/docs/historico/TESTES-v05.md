# Pede 0.5 - resultados e limites dos testes

## Resultados executados nesta entrega

| Grupo | Resultado | Evidencia |
| --- | --- | --- |
| Novos testes Python de WSGI, acesso, configuracao e backup | 46 passaram | `tests/v05/results.txt` |
| Regressao Python da versao 0.4 | 52 passaram | `tests/v05/regression-v04.txt` |
| Regras do carrinho e pedidos em JavaScript | 18 passaram | `tests/v05/domain.txt` |
| Aceite e registros de impressao em JavaScript | 20 passaram | `tests/v05/order-flow.txt` |
| Geometria, enderecos e taxas em JavaScript | 25 passaram | `tests/v05/delivery.txt` |
| Verificacoes da interface controlada e fluxo HTTP WSGI | 21 passaram | `tests/v05/browser-log.txt` e `tests/v05/artifacts/browser-results.json` |

Nao somar esses numeros como prova de cobertura completa ou seguranca. Ha cenarios relacionados em camadas diferentes.

## Cenários verificados

O codigo incorreto, alterado ou expirado bloqueia o piloto. Trocar o codigo invalida os acessos anteriores. Origem e Host inesperados sao rejeitados. A rota de saude nao revela configuracoes, usuarios ou pedidos. Fontes, banco, segredos e backups nao sao disponibilizados por HTTP.

A chave inicial e diferente do codigo de entrada. O responsavel so pode ser criado uma vez. Uma segunda tentativa nao deixa uma conta orfa. O cadastro comum de um lojista cria sua propria loja, nao assume o Cantinho. O cliente nao acessa o painel de preparacao do lojista.

Um pedido de exemplo com pastel, adicional e taxa da area B totalizou R$ 25,90. Duas sessoes separadas acompanharam o mesmo pedido. O aceite com prazo de 35 a 55 minutos chegou ao cliente. Foi injetada uma perda de resposta depois de salvar o pedido; repetir a confirmacao nao criou duplicacao. A reconexao atualizou o historico sem enviar um novo pedido.

Foi criada e verificada uma copia do banco contendo pedido. A restauracao em novo arquivo preservou o pedido e invalidou as sessoes/cotacoes temporarias. Arquivo alterado, origem inexistente e tentativas de sobrescrever arquivos foram rejeitados. O mesmo banco foi reaberto para verificar persistencia apos reconstruir o objeto da aplicacao.

O gerador de configuracao local tambem foi executado em pasta temporaria: criou um arquivo privado e preservou a configuracao numa segunda execucao. Nenhum segredo desse teste foi incluido no pacote.

## Limites relevantes

A tentativa de navegacao nativa do Chromium retornou `ERR_BLOCKED_BY_ADMINISTRATOR`. Essa politica nao foi alterada. As telas foram executadas com `set_content`; chamadas da interface foram encaminhadas a um servidor HTTP WSGI local real por sessoes `requests` separadas. Nao foram validados carregamento nativo por URL, cookies do navegador, sessionStorage persistente em uma origem real, HTTPS ou os aparelhos do restaurante.

O envio de impressao foi substituido por uma funcao de teste. Nenhuma impressora, pagamento, notificacao ou consulta real de endereco foi acionada. A perda de resposta e a desconexao foram simuladas pelo harness de teste.

Waitress nao foi instalado nem executado: o ambiente nao conseguiu baixar a dependencia. Docker nao estava disponivel. O adaptador WSGI e suas regras foram testados, mas o servidor hospedado, a imagem Docker, o volume real, um redeploy e os cabecalhos do proxy aguardam validacao. O script Windows tambem nao foi executado.

O importador antigo de PDF foi exercitado somente na regressao local com a dependencia ja existente, pypdf 5.9.0. Nao foi feita auditoria dessa versao nem atualizacao por download. Por esse motivo, o perfil hospedado nao instala a dependencia e mantem upload de PDF desativado. Revisar a dependencia e repetir os testes antes de habilita-lo.

## Reproduzir

```sh
python -m pip install -r requirements-dev.txt
python -m unittest discover -s tests/v05 -p 'test_*.py' -v
python -m unittest discover -s tests/v04 -p 'test_*.py' -v
node tests/domain.test.cjs
node tests/order-flow.test.cjs
node tests/delivery.test.cjs
python tests/v05/browser_flow.py
```

O teste de interface exige Chromium disponivel ou `CHROMIUM_PATH` configurado. As contas e chaves visiveis nos testes sao fixtures locais descartaveis, nao acessos a um servico publicado. Os bancos de teste usam diretorios temporarios e nao alteram os dados normais.

Passar estes testes nao significa estar pronto para atender pedidos reais.
