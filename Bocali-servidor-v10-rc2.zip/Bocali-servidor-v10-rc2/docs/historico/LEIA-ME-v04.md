# Pede 0.4 - piloto conectado

Nome provisório. Cantinho do Pastel como loja piloto. Preços, cardápios, endereços e áreas iniciais são fictícios. Não substituir o GloriaFood ou atender clientes reais com esta entrega.

## O que mudou

Cadastro e login agora são executados no servidor. Contas, favoritos, catálogos, áreas, pedidos, prazos e registros de impressão persistem em SQLite. Cliente e lojista em sessões diferentes acessam o mesmo banco quando se conectam ao mesmo servidor.

O cliente consulta cardápios sem login; para salvar favoritos e enviar pedidos neste piloto, entra em uma conta. O lojista administra somente as lojas vinculadas à sua conta. A tela consulta atualizações a cada 4 segundos enquanto está visível. Não há push com o aplicativo fechado.

Os produtos e adicionais são precificados no servidor. Para entrega, o servidor verifica o ponto em relação às áreas, sem confiar no valor recebido do navegador. O consumidor vê um resumo antes de confirmar. Mudanças de valores, indisponibilidade e cotações expiradas bloqueiam o envio até nova conferência. Repetir o mesmo envio não cria outro pedido.

## Abrir uma imagem não é executar o aplicativo

As imagens em `previas/` são capturas da interface. A v0.4 depende do servidor: **não basta abrir `index.html` como arquivo**. Também não há um endereço público hospedado nesta entrega.

A demonstração antiga em `legacy/Pede-v03-visual.html` foi preservada apenas como referência. Ela não tem o login ou o banco desta versão. Dados das demonstrações anteriores no navegador não são migrados automaticamente.

## Começar no computador

Requer Python 3.11 ou superior e internet para instalar as dependências. Dependências fixadas nas versões usadas nos testes; revisar atualizações e vulnerabilidades antes de qualquer exposição externa.

No Windows, o arquivo `INICIAR-WINDOWS.bat` prepara um ambiente virtual e mostra duas opções. Na primeira execução, escolha configurar o responsável pelo Cantinho. O script Windows foi preparado, mas não foi executado em Windows nesta entrega.

O caminho por terminal, testado em Linux, é:

```sh
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python server.py --setup-owner
```

Crie um e-mail de teste e uma senha exclusiva de pelo menos 12 caracteres. Não use credenciais do GloriaFood, de e-mail, bancos ou outros serviços. A configuração do responsável é feita no terminal; um cadastro público não permite assumir o Cantinho.

O servidor informa o endereço local:

```text
http://127.0.0.1:8000
```

Mantenha o terminal aberto. Nas próximas execuções use `python server.py`, sem `--setup-owner`. Não existem contas ou senhas prontas no banco entregue: o banco só é criado na primeira execução.

## Primeiro teste completo

1. Entre como responsável e deixe o painel do Cantinho aberto.
2. Em outra sessão de navegador, crie uma conta em **Criar conta > Quero pedir**. Sessões separadas evitam trocar o acesso do lojista pelo do cliente.
3. Abra o Cantinho, adicione um produto e um adicional. Na entrega, use **Exemplo B**, confira o ponto e confirme a taxa. Os exemplos são fictícios.
4. Confira o resumo calculado pelo servidor e confirme o pedido de teste. No painel do responsável, aguarde a próxima atualização, aceite e informe o prazo.
5. Confira a previsão no cliente. Experimente a comanda sem encaminhar o papel à cozinha. Não preparar pedidos de teste.

Uma conta do tipo **Tenho uma loja** cria uma loja diferente, pausada, sem produtos e sem áreas de entrega. Ela não pode editar o Cantinho. Cadastre um produto, configure a entrega ou use retirada e libere a loja no painel para testar.

## Dados, autenticação e limites

O banco padrão é `data/pede.sqlite3`. Fechar o navegador não o apaga. Não copie apenas o arquivo SQLite enquanto houver escrita sem usar um procedimento de backup consistente; não há backup agendado ou restauração operacional nesta entrega. A pasta do banco não é servida por HTTP.

Senhas usam Argon2id; tokens de sessão opacos são representados por hash no banco. Cookies de sessão são HttpOnly e SameSite=Lax, com verificação de origem e token anti-CSRF nas escritas autenticadas. O atributo Secure depende de uma origem HTTPS configurada. No teste local padrão, o transporte é HTTP e não deve levar dados reais. O carrinho pode ficar em sessionStorage; credenciais e pedidos não são gravados em localStorage.

Sessão de até 12 horas, com expiração por inatividade de 2 horas; sair invalida a sessão no servidor. Limites de tentativas são locais ao processo. São controles implementados no piloto, não uma certificação de segurança.

O histórico retornado à interface é limitado aos 200 pedidos recentes do cliente e 300 recentes das lojas do responsável. Paginação, busca histórica e relatórios contábeis ainda precisam de desenvolvimento. Cada loja tem somente o perfil de responsável nesta versão; convites e permissões detalhadas para funcionários ainda não existem.

## Endereços e mapa

As áreas iniciais continuam sendo exemplos geométricos, não a cobertura real do Cantinho. O servidor não aceita coordenadas arbitrárias enviadas pelo cliente como prova de um endereço.

Para testes, ele reconhece quatro endereços fictícios fixos. Para o adaptador Geoapify, uma consulta autenticada emite um identificador temporário, vinculado à conta e ao resultado do provedor. A cotação usa esse resultado, e alterações de endereço exigem nova consulta. Complemento é registrado separadamente.

`GEOAPIFY_API_KEY` deve ser configurada no ambiente do servidor, nunca no JavaScript ou no chat. Nenhuma consulta real ou validação da cobertura de Pindamonhangaba foi feita nesta etapa. `PEDE_DEMO_ADDRESSES=0` bloqueia o uso dos exemplos no servidor, mas não transforma este piloto em um produto comercial. Limites, custos, termos e precisão do provedor precisam ser avaliados antes do uso real.

## PDF e impressão

O importador de PDF com texto foi mantido, agora restrito ao lojista autenticado. Limites: 10 MB, 25 páginas, 200 mil caracteres e 25 segundos para o processo de leitura. Limites de memória/CPU do subprocesso são aplicados quando o sistema oferece `resource` (não em Windows). Não há OCR, IA externa, extração automática de fotos ou interpretação garantida de tabelas.

O lojista precisa revisar todas as linhas antes de publicar pela interface. Nomes já cadastrados são preservados para evitar duplicação nessa importação. A publicação não depende de uma IA aprovar o conteúdo.

A comanda de 58/80 mm continua usando a janela de impressão do navegador. Solicitação, confirmação manual, falha e reimpressão ficam no banco. Não existe verificação automática de saída de papel nem integração direta com uma impressora física. O teste automatizado substituiu a chamada de impressão por uma função de teste.

## Antes de hospedar ou cobrar

Este servidor Python foi escrito para desenvolvimento local. Não exponha diretamente sua porta à internet. Antes de um piloto externo: preparar hospedagem com HTTPS e armazenamento persistente, servidor de aplicação adequado, revisão de segurança e dependências, validação/recuperação de contas, backups e restauração, monitoramento, teste de carga e permissões de equipe.

Depois: validar cardápio e áreas reais; conectar pagamentos e verificar confirmações, cancelamentos e estornos; testar impressora, som/notificações e falhas nos aparelhos do estabelecimento; revisar privacidade e termos. **Pix, cartão e dinheiro estão apenas identificados como simulação.** Nenhuma cobrança, conta externa, instalação em equipamento do restaurante ou alteração no GloriaFood ocorreu.

## Testes e referências

Veja `TESTES-v04.md`. As referências técnicas usadas como apoio estão abaixo; não substituem uma auditoria do produto.

```text
OWASP - Password Storage Cheat Sheet
https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
OWASP - Session Management Cheat Sheet
https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html
SQLite - Isolation
https://www.sqlite.org/isolation.html
```
